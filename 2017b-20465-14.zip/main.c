#include "prog.h"




int main(int argc, char *argv[])
{
	
		int i, ic, dc;
		char *file_name;	


		stp sth; /* pointer to head of symbol table */
 		dtp dth; /* pointer to head of data table */
		actSP actsh; /* pointer to head of action statement list. */	

		FILE *fp; /* file pointer */


		if(argc == 1)
		{
				fprintf(stderr, "No arguments only program name.\n");
				exit(0);
		}


		/* running on every file in argv array */
		for(i = FILE_START_INDEX; i < argc; i++)
		{

				sth = NULL;
  			dth = NULL;
  			actsh = NULL;


   			file_name = addExtension( argv[i], ".as" );

				if(!(fp = fopen(file_name, "r")))
				{
						fprintf(stderr, "Can't open file.\n");
						exit(0);
				}
				


				/*		start first run and if no error,
							start sec run.
							if no error in sec run, start printing tables.			*/

				if(firstRun(fp,&sth,&dth,&actsh, &ic, &dc) == no)
				{		
						fclose(fp);						
					
					 if(secondRun( sth, actsh) == no)
						{
								
								printList(argv[i], sth, dth, actsh, ic, dc);

								
						}
					
				}

				/*	clean the three tables	*/
				removeSymbolTable(&sth);
				removeDataTable(&dth);
				removeActionStatementList(&actsh);

			

		}

		return 0;
}



/* If the first run file is not right, remove the symbol table. */
void removeSymbolTable(stp *p)
{
	stp currPtr;
	
	while(*p)
	{
		currPtr = *p;
		*p = (*p)->next;
		free(currPtr);
	}
}

/* If the first run file is not right, remove the data table. */
void removeDataTable(dtp *p)
{
	dtp currPtr;
	
	while(*p)
	{
		currPtr = *p;
		*p = (*p)->next;
		free(currPtr);
	}	
}

/* If the first run file is not right, remove the action statement list. */
void removeActionStatementList(actSP *p)
{
	actSP currPtr;
	
	while(*p)
	{
		currPtr = *p;
		*p = (*p)->next;
		free(currPtr);
	}
}
